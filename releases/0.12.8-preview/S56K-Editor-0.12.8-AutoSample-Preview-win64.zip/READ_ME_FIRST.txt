S56K Editor 0.12.8 Auto Sample Preview — Windows 11 x64

Extract the complete ZIP into a new folder and run S56K-Editor.exe.
Keep all supporting files together, including the internal folder.
Only S56K-Editor.exe needs to be launched.

Open START_HERE.html for the illustrated full manual.
Open AUTO_SAMPLE_GUIDE.html for MIDI Keyboard and PC Auto Sample.
A printable manual is in docs/S56K-Editor-0.12.8-User-Guide.pdf.
RELEASE_NOTES.md and CHANGELOG.md describe the new features and fixes.

MIDI KEYBOARD routes a PC keyboard to the Akai over USB or to Auto Sample's
selected external synth / loaded VST3. Computer-side instruments do not
require the Akai sampler to be connected.

AUTO SAMPLE records hardware through your MIDI/audio interface or renders a
64-bit VST3 instrument. Choose notes and velocity layers, process and loop the
recordings, then export an AKP program and its WAVs into the selected folder.
Open the finished program in FILES to transfer it with its dependencies.
ASIO requires your interface manufacturer's installed 64-bit driver.
No instrument plugins or interface drivers are bundled.

Start Sampling records a new run. The previous export and settings may be
restored when reopening the Editor. New patch clears the name and review.
Use Resume project for incomplete work, or retain working recordings under
Details if you want to Reprocess recordings later.

For sampler control/transfers, an IB-S56USB card with Microsoft WinUSB is
required. If needed, open Tools > USB driver setup while disconnected.
Close ak.Sys and other applications using the sampler before connecting.
The sampler's USB connection does not carry audio.

Begin with a small capture or transfer and listen to the result. RAM is
temporary; save instruments and their samples on disk when you want to keep them.
Read LICENSE.md, DISCLAIMER.md and the third-party notices.
The firmware and standalone Firmware Updater are separate downloads.

Updates and support: https://github.com/Tubbritt/S56K-Editor
